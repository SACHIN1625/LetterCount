# LetterCount


.

## How to install

```
pip install LetterCount
```
## If you are trouble installing, try this
```
pip3 install LetterCount
```
## How to use

Below example will help you

```
from LetterCount install LetterCount
sample_string= "python"
LetterCount(sample_string,letter)	# returns the number of times letter occured in string


```


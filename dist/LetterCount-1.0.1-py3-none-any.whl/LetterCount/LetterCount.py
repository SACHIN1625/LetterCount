
def repetition(a,b):
    
    count=0;
    for i in range(len(a)):
       
        if(a[i]==b):
            count=count+1 
    return count

